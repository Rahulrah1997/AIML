import sys
sys.path.insert(0, r'D:\GUVI\AIML-Content\Prompt_Engineering-main\chatbot\Sri-Lanka-Tourism-ChatBot-main\Sri-Lanka-Tourism-ChatBot-main')
from src.vector_store import retriever
print('retriever type:', type(retriever))
print('has invoke:', hasattr(retriever, 'invoke'))
print('has retrieve:', hasattr(retriever, 'retrieve'))
print('has get_relevant_documents:', hasattr(retriever, 'get_relevant_documents'))
print('has get_relevant_results:', hasattr(retriever, 'get_relevant_results'))
print('methods snippet:', [n for n in dir(retriever) if any(sub in n.lower() for sub in ['invoke','retrieve','get_relevant'])])
