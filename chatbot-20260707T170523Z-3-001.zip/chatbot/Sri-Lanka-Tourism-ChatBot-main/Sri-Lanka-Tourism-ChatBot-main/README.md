# 🇱🇰 Sri Lanka Tourism RAG Chatbot

An intelligent Retrieval-Augmented Generation (RAG) chatbot that provides context-aware answers about tourism in Sri Lanka using web-scraped data, semantic search, and transformer-based language models.

---

##  Project Overview

This project is an end-to-end AI system that answers user queries about tourist destinations in Sri Lanka. It combines web scraping, natural language processing, and large language models to deliver accurate and meaningful responses.

Unlike traditional chatbots, this system retrieves relevant information from a custom-built knowledge base and generates human-like answers using a transformer model.

---

##  Live Demo

 https://thehoodguy4587-sri-lanka-tourism-chatbot-app-itzzw3.streamlit.app/

---

##  System Architecture
![Architecture](assets/architecture.png)

### Pipeline Flow:

1. Web Scraping (Tourism Data Collection)
2. Data Cleaning & Preprocessing
3. Text Chunking
4. Embedding Generation
5. Vector Storage (FAISS)
6. Retrieval
7. Re-ranking (Cross Encoder)
8. Answer Generation (LLM)
9. Streamlit User Interface

---

##  Data Collection (Web Scraping)

The dataset was collected using web scraping from publicly available tourism-related sources.

### Tools Used:

* BeautifulSoup / Selenium (depending on your implementation)

### Process:

* Extract tourism descriptions, locations, and attractions
* Clean and preprocess raw text
* Remove noise and irrelevant symbols
* Prepare structured data for embedding

---

##  Data Processing Example

### Before Cleaning:

```
Adam’s Peak (IAST...) Sinhala text... symbols...
```

### After Cleaning:

```
Adam’s Peak is a sacred mountain located in central Sri Lanka.
```

---

##  Tech Stack

* **Frontend:** Streamlit
* **LLM:** google/flan-t5-base
* **Embeddings:** sentence-transformers/all-MiniLM-L6-v2
* **Vector Database:** FAISS
* **Re-ranking Model:** cross-encoder/ms-marco-MiniLM-L-6-v2
* **Frameworks:** LangChain, Transformers
* **Data Collection:** Web Scraping

---

##  Project Structure

```
Sri-Lanka-Tourism-Chatbot/
│
├── app.py
├── requirements.txt
├── README.md
│
└── src/
    ├── rag_pipeline.py
    ├── vector_store.py
    ├── embedding_model.py
    ├── data_loader.py
    └── web_scrapping.py
    
```

---

##  Installation

```bash
git clone https://github.com/theHoodguy4587/Sri-Lanka-Tourism-ChatBot
cd sri-lanka-tourism-chatbot

pip install -r requirements.txt
```

---

##  Run Locally

```bash
streamlit run app.py
```

---

##  Application Interface

![App UI](assets/ui.png)

The user can:

* Enter tourism-related queries
* Receive context-aware answers
* Interact with a simple and clean UI

---

##  Example Query & Output

### Query:

```
Tell me about Ella
```

### Response:

Ella is a scenic town in Sri Lanka known for its lush greenery, tea plantations, and breathtaking viewpoints such as Ella Gap. It is a popular destination for hiking, with attractions like Little Adam’s Peak and Nine Arches Bridge.

---

##  RAG Pipeline Explanation

![RAG Flow](assets/rag_flow.png)

### Steps:

1. User enters a query
2. FAISS retrieves relevant document chunks
3. Cross-encoder re-ranks results
4. Top documents are passed to the LLM
5. LLM generates a final answer

---

##  Features

* Context-aware question answering
* Semantic search using vector embeddings
* Re-ranking for improved accuracy
* Clean and interactive UI
* Real-world data via web scraping
* End-to-end AI pipeline

---

##  Key Highlights

* Built a full RAG pipeline from scratch
* Collected real-world tourism data using web scraping
* Implemented semantic search with FAISS
* Improved retrieval quality using re-ranking
* Deployed an interactive chatbot using Streamlit

---

##  Future Improvements

* Chat history (multi-turn conversation)
* More powerful LLM (e.g., Mistral, LLaMA)
* Multilingual support (Sinhala / Tamil)
* Image-based recommendations
* Faster deployment and caching

---

##  Author

**Senitha Gunathilaka**
Data Science Enthusiast

---

##  Acknowledgements

* Hugging Face Transformers
* Sentence Transformers
* LangChain
* Streamlit

---

##  Notes

This project demonstrates practical skills in:

* Data collection
* Data preprocessing
* NLP and embeddings
* Information retrieval
* LLM integration
* Model deployment

---

